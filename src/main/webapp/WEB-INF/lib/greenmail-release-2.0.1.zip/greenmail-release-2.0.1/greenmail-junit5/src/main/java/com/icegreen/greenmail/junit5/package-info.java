/**
 * Package contains junit5 extension logic.
 */

package com.icegreen.greenmail.junit5;
