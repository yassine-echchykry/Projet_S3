package com.icegreen.greenmail.imap.commands;

/**
 * Created on 10/03/2016.
 *
 * @author Reda.Housni-Alaoui
 */
public enum SortKey {
    ARRIVAL,
    CC,
    DATE,
    FROM,
    REVERSE,
    SIZE,
    SUBJECT,
    TO
}
